package com.kkgrocery.model;

public class WorkSpaceCity {

    private String work_city_id;
    private String language_id;
    private String work_city_name;
    private String work_city_status;
    private String is_created_date;

    public String getLanguage_id() {
        return language_id;
    }

    public void setLanguage_id(String language_id) {
        this.language_id = language_id;
    }

    public String getWork_city_id() {
        return work_city_id;
    }

    public void setWork_city_id(String work_city_id) {
        this.work_city_id = work_city_id;
    }

    public String getWork_city_name() {
        return work_city_name;
    }

    public void setWork_city_name(String work_city_name) {
        this.work_city_name = work_city_name;
    }

    public String getWork_city_status() {
        return work_city_status;
    }

    public void setWork_city_status(String work_city_status) {
        this.work_city_status = work_city_status;
    }

    public String getIs_created_date() {
        return is_created_date;
    }

    public void setIs_created_date(String is_created_date) {
        this.is_created_date = is_created_date;
    }
}
