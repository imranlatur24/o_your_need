package com.kkgrocery.model;

public class LanguageList
{
    private String language_id;
    private String language_name;
    private String language_status;
    private String is_created_date;

    public String getLanguage_id() {
        return language_id;
    }

    public void setLanguage_id(String language_id) {
        this.language_id = language_id;
    }

    public String getLanguage_name() {
        return language_name;
    }

    public void setLanguage_name(String language_name) {
        this.language_name = language_name;
    }

    public String getLanguage_status() {
        return language_status;
    }

    public void setLanguage_status(String language_status) {
        this.language_status = language_status;
    }

    public String getIs_created_date() {
        return is_created_date;
    }

    public void setIs_created_date(String is_created_date) {
        this.is_created_date = is_created_date;
    }
}
