package com.kkgrocery.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kkgrocery.R;
import com.kkgrocery.adapter.ProductAdapter;
import com.kkgrocery.data.APIService;
import com.kkgrocery.data.APIUrl;
import com.kkgrocery.data.AppDatabase;
import com.kkgrocery.data.ResponseResult;
import com.kkgrocery.model.Cartdb;
import com.kkgrocery.model.LocalityList;
import com.kkgrocery.model.ProductModel;
import java.util.ArrayList;
import es.dmoral.toasty.Toasty;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartListActivity extends BaseActivity implements View.OnClickListener, ProductAdapter.CallbackInterface {
    private Toolbar toolbar;
    private RecyclerView recyclerView_carts;
    private ProductAdapter productAdapter;
    private TextView text_total;
    private Menu menu;
    private ArrayList<LocalityList> arrayList = new ArrayList<>();
    private ArrayList<ProductModel> arrayProduct = new ArrayList<>();
    private ArrayList<Cartdb> cartArrayList = new ArrayList<>();
    private int total = 0;
    private int price = 0;
    private int item = 0;
    private MenuItem searchItem;
    private Button btnRetry,submit_order;
    private LinearLayout errorLayout, linear_cart_bottom;
    private TextView txtError;
    private String user_id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCurrentLanguage();
        setContentView(R.layout.cart_list);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getResources().getString(R.string.mycart));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();
    }

    private void init() {

        prefManager.connectDB();
        user_id = prefManager.getString("userId");
        prefManager.closeDB();

        //for recyclerview
        //initilize recyclerview
        text_total = findViewById(R.id.text_total);
        errorLayout = (LinearLayout) findViewById(R.id.error_layout);
        linear_cart_bottom = (LinearLayout) findViewById(R.id.linear_cart_bottom);
        btnRetry = (Button) findViewById(R.id.error_btn_retry);
        submit_order = (Button) findViewById(R.id.submit_order);
        btnRetry.setText("Go Back");
        txtError = (TextView) findViewById(R.id.error_txt_cause);

        cartArrayList = (ArrayList<Cartdb>) AppDatabase.getAppDatabase(CartListActivity.this).adminDao().getAllProduct();
        //get data from roomer db and add  SET to LocalityList model call
        for(Cartdb cartdb :cartArrayList)
        {
            LocalityList data = new LocalityList();
            data.setProductId(cartdb.getPro_id());
            data.setProductName(cartdb.getTitle());
            data.setProductPrice(cartdb.getPro_price());
            data.setProductQty("1");
            data.setProductImage(cartdb.getPro_image());
            arrayList.add(data);
            total = total + 1;
            item = item + Integer.parseInt(cartdb.getPro_total());
            price = Integer.parseInt(cartdb.getPro_price())*Integer.parseInt(cartdb.getPro_total())+price;
        }

        //print total value of product ex 100 rupees
        text_total.setText(getResources().getString(R.string.order)+getResources().getString(R.string.Rs)+price);

        //initilization of recyclerview in vertical format
        recyclerView_carts = findViewById(R.id.recyclerView_carts);
        recyclerView_carts.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL); // set Horizontal Orientation
        recyclerView_carts.setLayoutManager(linearLayoutManager); // set LayoutManager to RecyclerView

        //set productAdapter to recyclerview_cards
        productAdapter = new ProductAdapter(CartListActivity.this,false);
        productAdapter.setListArray(arrayList);
        recyclerView_carts.setAdapter(productAdapter);

        //if cardview CardDB is empty
        if(cartArrayList.isEmpty()){
            recyclerView_carts.setVisibility(View.GONE);
            linear_cart_bottom.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
        }else {//if not cardview CardDB is an empty
            recyclerView_carts.setVisibility(View.VISIBLE);
            linear_cart_bottom.setVisibility(View.VISIBLE);
            errorLayout.setVisibility(View.GONE);
        }
        btnRetry.setOnClickListener(this);
        submit_order.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case android.R.id.home :
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

   /* public void setCount(Context context, String count) {
        MenuItem menuItem = menu.findItem(R.id.action_cart);
        LayerDrawable icon = (LayerDrawable) menuItem.getIcon();

        CountDrawable badge;

        // Reuse drawable if possible
        Drawable reuse = icon.findDrawableByLayerId(R.id.ic_group_count);
        if (reuse != null && reuse instanceof CountDrawable) {
            badge = (CountDrawable) reuse;
        } else {
            badge = new CountDrawable(context);
        }

        badge.setCount(count);
        icon.mutate();
        icon.setDrawableByLayerId(R.id.ic_group_count, badge);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        prefManager.connectDB();
        setCount(this, "3");
        prefManager.closeDB();
        return true;
    }*/



    private void checkoutNow() {
       /* new DroidDialog.Builder(CartListActivity.this)
                .animation(Animation.RELATIVE_TO_PARENT)
                .icon(R.drawable.ic_check)
                .title(getString(R.string.app_name))
                .content(getString(R.string.Checkout_now))
                .cancelable(true, true)
                .positiveButton(getResources().getString(R.string.check_out_now), new DroidDialog.onPositiveListener() {
                    @Override
                    public void onPositive(Dialog droidDialog) {
                        droidDialog.dismiss();
                        placeOrder();
                        
                    }
                })
                .negativeButton(getResources().getString(R.string.cancel), new DroidDialog.onNegativeListener() {
                    @Override
                    public void onNegative(Dialog droidDialog) {
                        droidDialog.dismiss();
                    }
                })
                .show();*/

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        alertDialogBuilder.setTitle(getString(R.string.app_name));
        alertDialogBuilder.setIcon(R.drawable.logo);
        alertDialogBuilder.setMessage(R.string.Checkout_now);
        alertDialogBuilder.setCancelable(false);

        alertDialogBuilder.setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                placeOrder();
            }
        });

        alertDialogBuilder.setNegativeButton(getResources().getString(R.string.No), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void placeOrder() {
        cartArrayList = (ArrayList<Cartdb>) AppDatabase.getAppDatabase(CartListActivity.this).adminDao().getAllProduct();
        if (cartArrayList.isEmpty()) {
            Toasty.error(CartListActivity.this,getResources().getString(R.string.cartempty),Toasty.LENGTH_SHORT).show();
            return;
        }
        if(!isNetworkAvailable()){
            Toasty.error(CartListActivity.this,getResources().getString(R.string.error_msg_no_internet),Toasty.LENGTH_SHORT).show();
            return;
        }
        total = 0;
        item = 0;
        price = 0;
        for(Cartdb cartdb :cartArrayList){
            int sum = Integer.parseInt(cartdb.getPro_total())*Integer.parseInt(cartdb.getPro_price());
            ProductModel data = new ProductModel();
            data.setProduct_name(cartdb.getTitle());
            data.setProduct_image(cartdb.getPro_image());
            data.setProduct_price(cartdb.getPro_price());
            data.setProduct_minimum_qty("1");
            data.setProduct_unit("kg");
            data.setProduct_qty(cartdb.getPro_total());
            data.setProduct_total_price(String.valueOf(sum));
            arrayProduct.add(data);
            total = total + 1;
            item = item + Integer.parseInt(cartdb.getPro_total());
            price = Integer.parseInt(cartdb.getPro_price())*Integer.parseInt(cartdb.getPro_total())+price;
        }

        // Use this builder to construct a Gson instance when you need to set configuration options other than the default.
        GsonBuilder gsonBuilder = new GsonBuilder();

        // This is the main class for using Gson. Gson is typically used by first constructing a Gson instance and then invoking toJson(Object) or fromJson(String, Class) methods on it.
        // Gson instances are Thread-safe so you can reuse them freely across multiple threads.
        Gson gson = gsonBuilder.create();

        String JSONObject = gson.toJson(arrayProduct);
        System.out.println("\nConverted JSONObject ==> " + JSONObject);

        final ProgressDialog progressDialog = new ProgressDialog(this, R.style.AppCompatAlertDialogStyle);
        progressDialog.setMessage(getResources().getString(R.string.loading));
        progressDialog.show();

        System.out.println("Order user_id "+user_id+" item "+item+" price"+price+" JSONObject"+JSONObject);


        APIUrl.getClient().create(APIService.class).callOrderPlace(APIUrl.KEY,
                user_id,
                String.valueOf(item),
                String.valueOf(price),
                "1",
                JSONObject).enqueue(new Callback<ResponseResult>() {
            @Override
            public void onResponse(Call<ResponseResult> call, Response<ResponseResult> response) {
                progressDialog.dismiss();
                if(Integer.parseInt(response.body().getResponse()) == 101){

                    Toasty.success(CartListActivity.this,getResources().getString(R.string.orderplacedsuccefully),Toasty.LENGTH_SHORT).show();
                    AppDatabase.getAppDatabase(CartListActivity.this).adminDao().getAllDeleteProduct();
                    Intent intent = new Intent(CartListActivity.this, OrderActivity.class);
                    intent.putExtra("order",true);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }else {
                    Toasty.error(CartListActivity.this,getResources().getString(R.string.error_order),Toasty.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseResult> call, Throwable t) {
                progressDialog.dismiss();
                errorOut(t);
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case  R.id.error_btn_retry:
                finish();
                break;
            case R.id.submit_order:
                checkoutNow();
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.products_menu, menu);
        this.menu = menu;
        searchItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
       // ImageView locButton = (ImageView) menu.findItem(R.id.action_refresh_sort).getActionView();
        ImageView action_EditSearch = (ImageView) menu.findItem(R.id.action_search).getActionView();

        ((EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text)).setHintTextColor(getResources().getColor(R.color.white));
        ((EditText) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text)).setTextColor(getResources().getColor(R.color.white));



        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String searchQuery) {
                try {
                    productAdapter.getFilter(searchQuery.toString().trim());
                    recyclerView_carts.invalidate();
                    return true;
                }catch (NullPointerException e){

                    return true;
                }
            }
        });
        return true;
    }
    @Override
    public void onHandleSelection(String text, ArrayList<Cartdb> list) {
        text_total.setText(text);
        if(list.isEmpty()){
            recyclerView_carts.setVisibility(View.GONE);
            linear_cart_bottom.setVisibility(View.GONE);
            errorLayout.setVisibility(View.VISIBLE);
        }else {
            recyclerView_carts.setVisibility(View.VISIBLE);
            linear_cart_bottom.setVisibility(View.VISIBLE);
            errorLayout.setVisibility(View.GONE);
        }
    }
}
